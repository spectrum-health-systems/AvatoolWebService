	The solutions contained within this tutorial are saved in the Visual Studio 2010 format.  However, the project target the 3.5 .Net framework and will work in visual studio 2008 if you make the following changes to the .sln, .csproj, and .vbproj files.

Relace the first entry with the value below it if it exists in each solution or project file.

# Visual Studio 10
# Visual Studio 2008

Microsoft Visual Studio Solution File, Format Version 11.00
Microsoft Visual Studio Solution File, Format Version 10.00

<Project ToolsVersion="4.0"
<Project ToolsVersion="3.5"

<ProductVersion>10.0.20506</ProductVersion>
<ProductVersion>9.0.30729</ProductVersion>

\VisualStudio\v10.0\
\VisualStudio\v9.0\