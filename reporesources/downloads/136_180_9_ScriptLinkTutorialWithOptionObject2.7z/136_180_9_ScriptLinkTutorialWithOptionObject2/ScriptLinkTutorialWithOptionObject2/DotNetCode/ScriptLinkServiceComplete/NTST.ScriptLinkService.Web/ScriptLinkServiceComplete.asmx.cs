﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using NTST.ScriptLinkService.Objects;

namespace NTST.ScriptLinkService.Web
{
    /// <summary>
    /// Summary description for ScriptLinkService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ScriptLinkServiceComplete : System.Web.Services.WebService
    {
        [WebMethod]
        public string GetVersion()
        {
            return "Version 1.0";
        }

        [WebMethod]
        public OptionObject2 RunScript(OptionObject2 optionObject, String scriptName)
        {
            OptionObject2 returnOptionObject = new OptionObject2();
            //initialize the option object
            returnOptionObject.EntityID = optionObject.EntityID;
            returnOptionObject.OptionId = optionObject.OptionId;
            returnOptionObject.Facility = optionObject.Facility;

            /* logic statements should be used below to ensure
             * only the environment you want to execute ScriptLink calls for
             * setting these values to the optionObject values passed from the request 
             * will result in the logic always executing 
             * For example:
             * If (optionObject.SystemCode.Equals("BUILD")) { 
             * //logic for BUILD
             * ..}
             */
            returnOptionObject.ServerName = optionObject.ServerName;
            returnOptionObject.ParentNamespace = optionObject.ParentNamespace;
            returnOptionObject.NamespaceName = optionObject.NamespaceName;
            returnOptionObject.SystemCode = optionObject.SystemCode;

            switch (scriptName)
            {
                case "SuicideRiskAssessment":
                    returnOptionObject = SuicideRiskAssessment(optionObject);
                    break;
                case "ViewOptionObject":
                    //create a page to view the option object and launch the URL
                    var fileName = CreateHTMLPage.GetHTMLPage(optionObject);
                    returnOptionObject.ErrorCode = 5;
                    returnOptionObject.ErrorMesg = "http://" + Context.Request.Url.Host + System.Web.VirtualPathUtility.GetDirectory(Context.Request.RawUrl) + fileName;
                    break;
                default:
                    break;
            }

            return returnOptionObject;
        }

        private OptionObject2 SuicideRiskAssessment(OptionObject2 optionObject)
        {
            OptionObject2 returnOptionObject = new OptionObject2();
            int score;

            score = 0;
            foreach (var form in optionObject.Forms)
            {
                foreach (var currentField in form.CurrentRow.Fields)
                {
                    try
                    {
                        switch (currentField.FieldNumber)
                        {
                            case "126.97":
                            case "126.99":
                            case "127.01":
                            case "127.03":
                            case "127.05":
                            case "127.07":
                            case "127.09":
                            case "127.11":
                            case "127.13":
                            case "127.15":
                            case "127.17":
                            case "127.19":
                            case "127.25":
                                score += int.Parse(currentField.FieldValue);
                                break;
                            case "127.21":
                                if (currentField.FieldValue.Equals("1"))
                                {
                                    score += 1;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        //handle conversion errors here - log exception, etc
                    }
                }
            }


            var returnMessage = "Client is at low to moderate risk of suicide, supportive services should be arranged as appropriate.";

            if (score >= 9)
            {
                returnMessage = "Results indicate that client is at HIGH RISK of attempting or committing suicide. Immediate inpatient psychiatric services are strongly recommended.";
                // send email or text message
                var sendTo = "who@yourdomain.com";
                var subject = "Suicide Alert";
                var message = "Results indicate that a client in your caseload is at HIGH RISK of attempting or committing suicide. Immediate inpatient psychiatric services are strongly recommended. Please call 555-1212.";
                //send message
                //var retMessage = SendMail(sendTo, subject, message)
                //returnOptionObject.ErrorMesg = returnMessage + "\r\n" + "\r\n" + retMessage;
            }

            var fields = new FieldObject[1];
            var field = new FieldObject();
            var forms = new FormObject[1];
            var formObject = new FormObject();
            var currentRow = new RowObject();

            field.FieldNumber = "128.56";
            field.FieldValue = score.ToString();
            field.Enabled = "0";
            fields[0] = field;

            currentRow.Fields = fields;
            currentRow.RowId = optionObject.Forms[0].CurrentRow.RowId;
            currentRow.ParentRowId = optionObject.Forms[0].CurrentRow.ParentRowId;
            currentRow.RowAction = "EDIT";

            formObject.FormId = "927";
            formObject.CurrentRow = currentRow;
            forms[0] = formObject;

            returnOptionObject.ErrorCode = 3;
            returnOptionObject.ErrorMesg = returnMessage;
            returnOptionObject.EntityID = optionObject.EntityID;
            returnOptionObject.OptionId = optionObject.OptionId;
            returnOptionObject.ServerName = optionObject.ServerName;
            returnOptionObject.ParentNamespace = optionObject.ParentNamespace;
            returnOptionObject.NamespaceName = optionObject.NamespaceName;
            returnOptionObject.SystemCode = optionObject.SystemCode;
            returnOptionObject.Facility = optionObject.Facility;
            returnOptionObject.Forms = forms;

            return returnOptionObject;

        }
    }
}
